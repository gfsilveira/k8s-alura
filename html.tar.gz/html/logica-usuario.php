<?php
function usuarioEstaLogado() {
	
}

function verificaUsuario() {
 
}

function usuarioLogado() {

}

function logaUsuario($email) {
	
}

function logout() {

}
